__version__ = "0.2.2"
__description__ = "aamt is a api-automation-testing tool to help you write pytest more easily"
